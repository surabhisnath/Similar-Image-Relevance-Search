import cv2
import numpy as np 
from glob import glob 
import argparse
from helpers import *
from matplotlib import pyplot as plt 
import pickle

class BOV:
    def __init__(self, no_clusters):
        self.no_clusters = no_clusters
        self.train_path = None
        self.test_path = None
        self.im_helper = ImageHelpers()
        self.bov_helper = BOVHelpers(no_clusters)
        self.file_helper = FileHelpers()
        self.images = None
        self.trainImageCount = 0
        self.train_labels = np.array([])
        self.name_dict = {}
        self.descriptor_list = []
        self.filenames1 = None
        self.filenames2 = None

    def trainModel(self):

        d = {}
        ground_truth = "./relevant.txt"
        gt = open(ground_truth, 'r')
        lines = gt.readlines()
        # Make ground truth dictionary
        # ind = 0
        for line in lines:
            one = line.strip()
            arr = one.split(":")
            # d[ind] = arr[1].split(",")
            # ind += 1
            d[arr[0]] = arr[1].split(",")


        # read file. prepare file lists.
        self.filenames1, self.images, self.trainImageCount = self.file_helper.getFiles(self.train_path)
        

        # extract SIFT Features from each image
        label_count = 0 
        
        for word, imlist in self.images.items():
            
            self.name_dict[str(label_count)] = word
            print("Computing Features for ", word)
            
            for im in imlist:
                self.train_labels = np.append(self.train_labels, label_count)
                kp, des = self.im_helper.features(im)
                self.descriptor_list.append(des)

            label_count += 1


        # perform clustering
        print("In format ND")
        bov_descriptor_stack = self.bov_helper.formatND(self.descriptor_list)
        print("In cluster")
        self.bov_helper.cluster()
        print("In Develop Vocabulary")
        mega_histogram = self.bov_helper.developVocabulary(n_images = self.trainImageCount, descriptor_list=self.descriptor_list)

        print("OBTAINED MEGA HISTOGRAMMMMMMMMM: ", mega_histogram.shape)

        with open('mega_histogram.pk', 'wb') as f1:
            pickle.dump(mega_histogram, f1)

        # show vocabulary trained
        #self.bov_helper.plotHist()
        
        self.bov_helper.standardize()

        with open('bov_helper.pk', 'wb') as f:
            pickle.dump(self.bov_helper, f)


        # self.bov_helper.train(self.train_labels)

        return mega_histogram, d


    def recognize(self, test_img, test_image_path=None):

        kp, des = self.im_helper.features(test_img)
        # print kp

        # generate vocab for test image
        vocab = np.array( [[ 0 for i in range(self.no_clusters)]])
        # locate nearest clusters for each of 
        # the visual word (feature) present in the image
        
        # test_ret =<> return of kmeans nearest clusters for N features
        test_ret = self.bov_helper.kmeans_obj.predict(des)
        # print test_ret

        # print vocab
        for each in test_ret:
            vocab[0][each] += 1

        # Scale the features
        vocab = self.bov_helper.scale.transform(vocab)
        
        return vocab
        
        '''
        # predict the class of the image
        lb = self.bov_helper.clf.predict(vocab)
        # print "Image belongs to class : ", self.name_dict[str(int(lb[0]))]
        return lb
        '''

    def finddist(self, feature1, feature2):
        res = np.absolute(feature1 - feature2)
        toret = sum(res)
        return toret

    def callind(self, n):
        return n[1]

    def testModel(self, mega_histogram, d):

        val = 15

        with open('mega_histogram.pk', 'rb') as f2:
            mega_histogram = pickle.load(f2)
        # with open('kmeans_obj.pk', 'rb') as f3:
        #     self.bov_helper.kmeans_obj = pickle.load(f3)
        with open('bov_helper.pk', 'rb') as f4:
            self.bov_helper = pickle.load(f4)

        d = {}
        ground_truth = "./relevant.txt"
        gt = open(ground_truth, 'r')
        lines = gt.readlines()

        ##################

        # Make ground truth dictionary
        for line in lines:
            one = line.strip()
            arr = one.split(":")
            # d[ind] = arr[1].split(",")
            # ind += 1
            d[arr[0]] = arr[1].split(",")

        self.filenames1, self.images, self.trainImageCount = self.file_helper.getFiles(self.train_path)

        ##################

        self.filenames2, self.testImages, self.testImageCount = self.file_helper.getFiles(self.test_path)
        


        for word, imlist in self.testImages.items():
            #print("processing ", word)
            print("####################################################################################")
            print("K = ", val)
            anothercnt = 0
            total_cnt = 0
            total_cnt_avg = 0
            for im in imlist:
                print("QUERY IMAGE NUMBER: ", anothercnt+1)
                #cl = self.recognize(im)
                feature = self.recognize(im)
                feature = feature.squeeze()
                tuple_list = []
                for i in range(len(mega_histogram)):
                    temp = self.finddist(feature, mega_histogram[i])
                    tuple_list.append((self.filenames1[i],temp))
    
                sorted_tuples = sorted(tuple_list, key = self.callind)
                sorted_tuples_20 = sorted_tuples[0:val+1]
                queryimgname = self.filenames2[anothercnt]
                anothercnt += 1
                relevant = d[queryimgname[:-4]]
                
                cnt = 0
                for t in sorted_tuples_20:
                    name = t[0]
                    #print(name[:-4])
                    if name[:-4] in relevant:
                        cnt += 1
    
                print("MATCHES: ", cnt)
                print("PRECISION AT K: ", cnt/val)
    
                total_cnt += cnt
                total_cnt_avg += cnt/val
    

        print("OVERALL RESULT")
        print("AVG MATCHES: ", total_cnt/anothercnt)
        print("AVG PRECISION AT K: ", total_cnt_avg/anothercnt)


                # print(cl)
                # predictions.append({
                #     'image':im,
                #     'class':cl,
                #     'object_name':self.name_dict[str(int(cl[0]))]
                #     })

        '''
        print(predictions)
        for each in predictions:
            # cv2.imshow(each['object_name'], each['image'])
            # cv2.waitKey()
            # cv2.destroyWindow(each['object_name'])
            # 
            plt.imshow(cv2.cvtColor(each['image'], cv2.COLOR_GRAY2RGB))
            plt.title(each['object_name'])
            plt.show()
        '''


    def print_vars(self):
        pass


if __name__ == '__main__':

    # parse cmd args
    parser = argparse.ArgumentParser(description=" Bag of visual words example")
    parser.add_argument('--train_path', action="store", dest="train_path", required=True)
    parser.add_argument('--test_path', action="store", dest="test_path", required=True)

    args =  vars(parser.parse_args())
    print(args)
    
    bov = BOV(no_clusters=100)

    # set training paths
    bov.train_path = args['train_path'] 
    # set testing paths
    bov.test_path = args['test_path']

    mh = None
    d = None 
    # train the model
    # mh, d = bov.trainModel()
    # test model
    bov.testModel(mh, d)
