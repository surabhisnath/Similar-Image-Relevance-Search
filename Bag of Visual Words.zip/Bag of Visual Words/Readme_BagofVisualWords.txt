Run Bag of Visual Words

Version used - Python 3


Directory Structure:

- Bag.py
- helpers.py
- KMeans.py
- relevant.txt
- bov_helper.pk
- kmeans_obj.pk
- mega_histogram.pk
- images/
--- train
----- all
------- all .jpg database images
--- test
----- all
------- all .jpg query images



This code can be run with or with KMeans training

1) Without training:

Run
python Bag.py --train_path images/train/ --test_path images/test/

2) With training:

Make the following changes:
a) In Bag.py, uncomment the line 246 - mh, d = bov.trainModel()
b) Comment lines 130 to 152 in Bag.py - def testModel(self, mega_histogram, d)

Now run
python Bag.py --train_path images/train/ --test_path images/test/

