
# coding: utf-8

# In[317]:


import os
import numpy as np
from PIL import Image
import cv2


# In[318]:


data_path = "./data/images/"
query_path = "./data/queries/"
ground_truth = "./data/relevant.txt"


# In[319]:


d = {}


# In[320]:


gt = open(ground_truth, 'r')
lines = gt.readlines()


# In[321]:


# Make ground truth dictionary
for line in lines:
    one = line.strip()
    arr = one.split(":")
    d[arr[0]] = arr[1].split(",")


# In[322]:


images = os.listdir(data_path)
query_images = os.listdir(query_path)


# In[330]:


# Create Feature dict
feature_dict = {}
hist = []
bins = []
for image in images:
    img = cv2.imread(data_path+image, 1)
    #h, b = np.histogram(img.ravel(),256,[0,256])
    h = cv2.calcHist([img], channels = [0], mask = None, histSize = [256], ranges = [0, 256]);
    h = h.squeeze()
    hist.append(h)
    #bins.append(b)
    feature_dict[image] = h


# In[331]:


hist = np.array(hist)
print(hist.shape)


# In[332]:


# #Test feature distance measurement
# print(type(hist[0]) == type(hist[1]))
# print(hist[0].shape == hist[1].shape)
# cv2.compareHist(hist[0], hist[1], 0)


# In[333]:


def findfeatures(image):
    img = cv2.imread(query_path+image, 1)
    h = cv2.calcHist([img], channels = [0], mask = None, histSize = [256], ranges = [0, 256]);
    h = h.squeeze()
    return h


# In[334]:


def finddist(feature1, feature2):
    #print(feature1)
    #print(feature2)
    res = cv2.compareHist(feature1, feature2, 1)
    return res


# In[335]:


def callind(n):
    return n[1]


# In[336]:


val = 20
total_cnt = 0
total_cnt_avg = 0

for q in query_images:
    print(q)
    feature = findfeatures(q)
    
    tuple_list = []
    for img in images:
        temp = finddist(feature, feature_dict[img])
        tuple_list.append((img,temp))
    
    sorted_tuples = sorted(tuple_list, key = callind)
    #sorted_tuples_20 = sorted_tuples[len(sorted_tuples)-20:]
    sorted_tuples_20 = sorted_tuples[0:val+1]
    relevant = d[q[:-4]]
    relevant_20 = relevant[0:val+1]
    #print(relevant_20)
    cnt = 0
    for t in sorted_tuples_20:
        name = t[0]
        #print(name[:-4])
        if name[:-4] in relevant:
            cnt += 1
    
    print("MATCHES: ", cnt)
    print("PRECISION AT K: ", cnt/val)
    
    total_cnt += cnt
    total_cnt_avg += cnt/val
    

print("AVERAGE MATCHES: ", total_cnt/len(query_images))
print("AVERAGE PRECISION AT K: ", total_cnt_avg/len(query_images))

