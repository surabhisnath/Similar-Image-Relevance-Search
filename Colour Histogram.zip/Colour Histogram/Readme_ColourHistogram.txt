To run Colour Histogram:

Either run the .ipynb Python Notebook cell wise, or run the .py file.

Version used - Python 3

Directory Structure:
- py or ipynb code
- data
--- images
----- all .jpg dataset images
--- queries
----- all .jpg query images
--- relevant.txt
